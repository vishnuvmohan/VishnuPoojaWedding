const t=new Date("2026-11-22T10:00:00+05:30"),c=document.getElementById("cd");
function tick(){const d=t-new Date();if(d<=0){c.textContent="Today is the day";return}
const v=[["Days",d/864e5],["Hours",d/36e5%24],["Minutes",d/6e4%60],["Seconds",d/1e3%60]];
c.innerHTML=v.map(([l,n])=>`<div><b>${Math.floor(n)}</b>${l}</div>`).join("")}
tick();setInterval(tick,1000);
const L=[...document.querySelectorAll("nav a")],S=L.map(a=>document.querySelector(a.hash));
new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)L.forEach(a=>a.classList.toggle("on",a.hash==="#"+e.target.id))}),{rootMargin:"-30% 0px -60% 0px"}).observe&&S.forEach(s=>s&&new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)L.forEach(a=>a.classList.toggle("on",a.hash==="#"+e.target.id))}),{rootMargin:"-30% 0px -60% 0px"}).observe(s));
(()=>{const a=document.getElementById("bg"),b=document.getElementById("mu");let off=false;a.volume=.5;
const ui=()=>{const p=!a.paused;b.setAttribute("aria-pressed",p);b.setAttribute("aria-label",p?"Pause background music":"Play background music")};
const go=()=>a.play().then(ui).catch(()=>{});
const first=e=>{if(e.target.closest&&e.target.closest("#mu"))return;if(!off)go();["pointerdown","keydown","touchend"].forEach(e=>removeEventListener(e,first))};
["pointerdown","keydown","touchend"].forEach(e=>addEventListener(e,first,{passive:true}));
go();
b.addEventListener("click",e=>{e.stopPropagation();if(a.paused){off=false;go()}else{off=true;a.pause();ui()}});
a.addEventListener("play",ui);a.addEventListener("pause",ui);ui()})();
