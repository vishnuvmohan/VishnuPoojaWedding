Deploy: drag this whole folder onto app.netlify.com/drop.
Add photos: put them in images/ and add <img src="images/NAME.jpg" alt="..." loading="lazy"> inside the gallery div in index.html.
Music: replace audio/music.mp3 to change the song. It starts on the first tap or click (browsers block autoplay); a button at bottom-right pauses it.
RSVP replies appear in Netlify > Forms. Edit story and guest text in index.html.
